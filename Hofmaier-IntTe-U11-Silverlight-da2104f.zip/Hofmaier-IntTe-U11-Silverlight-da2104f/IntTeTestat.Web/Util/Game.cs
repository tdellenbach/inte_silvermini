﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.Diagnostics;

namespace IntTeTestat.Web.Util
{
	
	public class Game
	{
		private Dictionary<IGuessService, Player> players = new Dictionary<IGuessService, Player>();

		private const int maxNrOfPlayers = 3;
		private int secret = 3;

		private List<Guess> playedValues = new List<Guess>();

		public Game()
		{
			secret = new Random().Next(10);
			Debug.WriteLine("secretnumber: {0}", secret);
		}

		public void Add(Player player)
		{
			players.Add(player.ClientProxy, player);
			if (isFull())
			{
				Start();
			}
		}

		public bool isFull()
		{
			return players.Count == maxNrOfPlayers;
		}

		private void Start()
		{
			List<string> playerStrList = new List<string>();
			KeyValuePair<IGuessService, Player>[] copyiedPlayers = players.ToArray();
			foreach (KeyValuePair<IGuessService, Player> player in copyiedPlayers)
			{
				
				playerStrList.Add(player.Value.Name);
			}

			foreach (KeyValuePair<IGuessService, Player> player in copyiedPlayers)
			{
				player.Key.StartGame(playerStrList, player.Value.Name);
			}
		}

		public void Check(Int32 tipp)
		{
			
			IGuessService clientCallback = OperationContext.Current.GetCallbackChannel<IGuessService>();
			Player currentPlayer = players[clientCallback];
			Guess guess = new Guess(currentPlayer.Name, tipp.ToString());
			playedValues.Add(guess);
			KeyValuePair<IGuessService, Player>[] copyiedPlayers = players.ToArray();
			if (tipp == secret)
			{
				clientCallback.GameOver(true, playedValues);
				
				foreach (KeyValuePair<IGuessService, Player> player in copyiedPlayers)
				{
					if (player.Key != clientCallback)
					{
						player.Key.GameOver(false, playedValues);
					}
				}
			}

			else
			{
				
				if (tipp < secret)
				{
					guess.Tipp = GuessTipp.ToLow;
				}
				else
				{
					guess.Tipp = GuessTipp.ToHeight;
				}
				foreach (KeyValuePair<IGuessService, Player> player in copyiedPlayers)
				{
					player.Key.PlayerGuess(guess);
				}
			}
		}

		public void Leave()
		{
			IGuessService clientCallback = OperationContext.Current.GetCallbackChannel<IGuessService>();
			Player quitplayer = players[clientCallback];
			Guess msg = new Guess(quitplayer.Name, "Has Quit");
			playedValues.Add(msg);
			KeyValuePair<IGuessService, Player>[] copiedPlayers = players.ToArray();
			foreach (KeyValuePair<IGuessService, Player> player in copiedPlayers)
			{
				player.Key.PlayerGuess(msg);
				if (player.Key != clientCallback)
				{
					player.Key.ConnectCanceled();
				}
			}
			players.Remove(clientCallback);
		}
	}
}