﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntTeTestat.Web.Util
{
	public class GameManager
	{
		private static Game unstartedGame;

		public static Game JoinGame(Player player)
		{
			if (unstartedGame == null)
			{
				unstartedGame = new Game();
			}
			if (unstartedGame.isFull())
			{
				unstartedGame = new Game();
			}
			unstartedGame.Add(player);
			return unstartedGame;
		}
	}
}