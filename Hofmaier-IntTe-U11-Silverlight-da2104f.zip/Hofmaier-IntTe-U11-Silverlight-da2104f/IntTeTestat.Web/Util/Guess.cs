﻿using System;

namespace IntTeTestat.Web.Util
{
    public enum GuessTipp
    {
        ToLow,
        ToHeight,
        Correct,
        Others
    }


    [Serializable]
    public class Guess
    {
		//private Player player;
		private string guess;
		private string name;

		public Guess(string name, string guess)
		{
			//this.player = player;
			this.guess = guess;
			this.name = name;
		}

		public GuessTipp Tipp { set; get; }

    };
}