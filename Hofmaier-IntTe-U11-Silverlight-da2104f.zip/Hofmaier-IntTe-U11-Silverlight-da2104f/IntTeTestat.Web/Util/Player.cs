﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntTeTestat.Web.Util
{
	[Serializable]
	public class Player
	{
		private string name;
		private IGuessService client;

		public IGuessService ClientProxy
		{
			get
			{
				return client;
			}
		}

		public string Name
		{
			get
			{
				return name;
			}
		}

		public Player(string playername, IGuessService clienproxy)
		{
			name = playername;
			client = clienproxy;
		}
	}
}