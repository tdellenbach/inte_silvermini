﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace IntTeTestat
{
	public partial class Wait : UserControl
	{

		private MainPage mainpage;
		public Wait()
		{
			InitializeComponent();
			pictureAnimation.Begin();
		}

		public Wait(MainPage mp)
		{
			InitializeComponent();
			mainpage = mp;
			pictureAnimation.Begin();
		}

		private void cmdCancel_Click(object sender, RoutedEventArgs args)
		{
			WebContext.Current.GuessServiceClient.QuitConnectAsync();
			mainpage.ContentFrame.Content = new Info(mainpage);
		}
	}
}
