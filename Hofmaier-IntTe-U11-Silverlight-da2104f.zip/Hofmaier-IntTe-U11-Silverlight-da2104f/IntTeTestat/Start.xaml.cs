﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using IntTeTestat.GuessServiceReference;

namespace IntTeTestat
{
	public partial class Start : UserControl
	{
		private MainPage mainPage;

		public Start()
		{
			InitializeComponent();
			GuessServiceClient serviceClient = WebContext.Current.GuessServiceClient;
		}

		public Start(MainPage parent)
		{
			InitializeComponent();
			mainPage = parent;
		}


		private void cmdStart_Click(object sender, RoutedEventArgs e)
		{
			string nameStr = userName.Text;
			WebContext.Current.GuessServiceClient.AddNameAsync(nameStr);
			Wait wait = new Wait(mainPage);
			mainPage.ContentFrame.Content = wait;
		}
	}
}
