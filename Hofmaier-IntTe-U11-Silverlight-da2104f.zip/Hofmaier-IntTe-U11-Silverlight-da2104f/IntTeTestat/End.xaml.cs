﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace IntTeTestat
{
	public partial class End : UserControl
	{
		private MainPage mainPage;

		public End()
		{
			InitializeComponent();
		}

		public End(MainPage mp)
		{
			InitializeComponent();
			mainPage = mp;
		}

		private void cmdHome_Click(object sender, RoutedEventArgs e)
		{
			mainPage.GameContext = null;
			Info startPage = new Info(mainPage);
			mainPage.ContentFrame.Content = startPage;
		}
	}
}
