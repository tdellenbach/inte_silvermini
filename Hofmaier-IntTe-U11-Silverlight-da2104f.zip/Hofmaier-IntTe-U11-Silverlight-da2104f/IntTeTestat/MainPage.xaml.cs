﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using IntTeTestat.GuessServiceReference;
using IntTeTestat.ViewModel;
using System.Collections.ObjectModel;

namespace IntTeTestat
{
    public partial class MainPage : UserControl
    {
		private GameContext gameContext;

        public MainPage()
        {
            InitializeComponent();
			GuessServiceClient serviceClient = WebContext.Current.GuessServiceClient;
            serviceClient.StartGameReceived += OnStartGameReceived;
			serviceClient.GameOverReceived += OnGameOverReceived;
			serviceClient.ConnectCanceledReceived += OnConnectCanceledReceived;
			ContentFrame.Content = new Info(this);
		}

		public GameContext GameContext
		{
			get
			{
				if (gameContext == null)
				{
					gameContext = new GameContext();
				}
				return gameContext;
			}
			set
			{
				gameContext = value;
			}
		}
       
        private void OnStartGameReceived(object sender, StartGameReceivedEventArgs e)
        {
			GameContext.Name = e.playerName;
			GameContext.Players = e.players;
			Guess guessCtr = new Guess(this);
			guessCtr.DataContext = GameContext;
			ContentFrame.Content = guessCtr;
        }

		private void OnGameOverReceived(object sender, GameOverReceivedEventArgs e)
		{
			GameContext.Victory = e.victory;
			ObservableCollection<GuessServiceReference.Guess> playedVals = e.playedValues;
			ObservableCollection<GuessEntrie> endResultEntries = new ObservableCollection<GuessEntrie>();
			foreach (GuessServiceReference.Guess guess in playedVals) 
			{
				EndResultEntrie entrie = new EndResultEntrie();
				entrie.Name = guess.name;
				entrie.Guess = guess.guess;
				endResultEntries.Add(entrie);
			}

			GameContext.PlayedValues = endResultEntries;
		
			End endpage = new End(this);
			endpage.DataContext = GameContext;
			ContentFrame.Content = endpage;
		}

		private void OnConnectCanceledReceived(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
		{
			ContentFrame.Content = new Wait();
		}
    }



    /// <summary>
    /// Add GuessServiceClient to WebContext
    /// </summary>
    public sealed partial class WebContext
    {
        private GuessServiceClient _proxy;
        public GuessServiceClient GuessServiceClient
        {
            get
            {
                
                if (_proxy == null)
                {
                    EndpointAddress address = new EndpointAddress("http://localhost:1701/GuessService.svc");
                    PollingDuplexHttpBinding binding = new PollingDuplexHttpBinding();
                    _proxy = new GuessServiceClient(binding, address);
                    _proxy.ConntectAsync();
                }
                return _proxy;
            }
        }
    }
}
