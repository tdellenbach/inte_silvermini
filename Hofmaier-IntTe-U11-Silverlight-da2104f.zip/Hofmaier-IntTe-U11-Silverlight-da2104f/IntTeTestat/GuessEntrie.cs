﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace IntTeTestat
{
	public class GuessEntrie
	{
		public string Name{get; set;}
		public string Guess { get; set; }
		public GuessServiceReference.GuessTipp Tipp { get; set; }

		public override string ToString()
		{
			string listItem = "";
			if (Tipp == GuessServiceReference.GuessTipp.ToLow)
			{
				 listItem = Name + ":" + Guess + "\n" + "Dieser Tipp war zu klein";
			}
			else
			{
				 listItem = Name + ":" + Guess + "\n" + "Dieser Tipp war zu gross";
			}
			return listItem;
		}
	}

	public class EndResultEntrie : GuessEntrie
	{
		public override string ToString()
		{
			return Name + ":" + Guess;
		}
	}

}
