﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using IntTeTestat.GuessServiceReference;

namespace IntTeTestat
{
	public partial class Guess : UserControl
	{
		private MainPage mainpage;
		public Guess()
		{
			InitializeComponent();
			WebContext.Current.GuessServiceClient.PlayerGuessReceived += OnPlayerGuessReceived;
		}

		public Guess(MainPage mp)
		{
			InitializeComponent();
			WebContext.Current.GuessServiceClient.PlayerGuessReceived += OnPlayerGuessReceived;
			mainpage = mp;
		}

		private void cmdGuess_Click(object sender, RoutedEventArgs e)
		{
			GameContext context = (GameContext)DataContext;
			WebContext.Current.GuessServiceClient.GuessAsync(context.Tipp);
		}

		private void cmdCancel_Click(object sender, RoutedEventArgs e)
		{
			WebContext.Current.GuessServiceClient.QuitConnectAsync();
			mainpage.ContentFrame.Content = new Info(mainpage);
		}

		private void OnPlayerGuessReceived(object sender, PlayerGuessReceivedEventArgs e)
		{
			GameContext context = (GameContext)DataContext;
			GuessEntrie entrie = new GuessEntrie();
			if (e.guess.guess.Equals("Has Quit"))
			{
				entrie = new EndResultEntrie();
			}
			entrie.Guess = e.guess.guess;
			entrie.Tipp = e.guess.Tippk__BackingField;
			entrie.Name = e.guess.name;
			context.PlayedValues.Add(entrie);
		}
	}
}
