﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace IntTeTestat.Views
{
    public partial class Game : Page
    {
        public Game()
        {
            InitializeComponent();
            WebContext.Current.GuessServiceClient.GameOverReceived += GuessServiceClient_GameOverReceived;          
        }

        void GuessServiceClient_GameOverReceived(object sender, GuessServiceReference.GameOverReceivedEventArgs e)
        {
            NavigationService.Navigate(new Uri("\\GameOver", UriKind.Relative));
        }



        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void guessButton_Click(object sender, RoutedEventArgs e)
        {
            WebContext.Current.GuessServiceClient.GuessAsync(Convert.ToInt32(guessTxt.Text));
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            WebContext.Current.GuessServiceClient.GuessAsync(-1);
            WebContext.Current.GuessServiceClient.QuitConnectAsync();
            NavigationService.Navigate(new Uri("\\Intro", UriKind.Relative));
        }

     

    }
}
