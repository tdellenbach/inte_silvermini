﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IntTeTestat.GuessServiceReference;

using System.Linq;

namespace IntTeTestat.ViewModel
{
    public class GameModel : INotifyPropertyChanged
    {
        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        public ObservableCollection<Guess> Guesses { get; set; }
        public ObservableCollection<string> Players { get; set; }
        public bool Victory { get; set; }

        public string VictoryText { get { if (Victory) return "Sie haben gewonnen!"; else return "Sie haben leider verloren."; } }

        private string userName;

        public string UserName
        {
            get { return userName; } //userName; }
            set
            {
                userName = value;
                SendPropertyChanged("UserName");                
            }
        }

        public GameModel()
        {
            Guesses = new ObservableCollection<Guess>();
            Players = new ObservableCollection<string>();
                        
        }

        /// <summary>
        /// Sends the property changed.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected void SendPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
