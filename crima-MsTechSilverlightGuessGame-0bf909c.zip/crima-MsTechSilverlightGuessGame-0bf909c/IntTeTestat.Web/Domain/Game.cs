﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IntTeTestat.Web.Util;

namespace IntTeTestat.Web.Domain
{
    public class Game
    {
       
        public bool Full { get{return players.Count >= maxPlayers;} }
        public bool Empty { get { return players.Count == 0; } }
        private List<Player> players = new List<Player>();
        private List<Guess> guesses = new List<Guess>();
        private int maxPlayers = 2;

        private int number;
        private bool running;

        public void Add(Player player)
        {
            players.Add(player);
            if (Full && !running)
                 Start();
            else if (running)
            {
                List<string> names = new List<string>();
                foreach (Player p in players)
                    names.Add(p.Name);
                foreach (Player p in players)
                    p.Client.StartGame(names, p.Name);
            }
        }

        private void Start()
        {
            //var names = from p in players select p.Name;
            //refactor me
            Random random = new Random();
            number = random.Next(0, 10);
            List<string> names = new List<string>();
            foreach (Player p in players)
                names.Add(p.Name);
            foreach (Player p in players)
                p.Client.StartGame(names, p.Name);
            running = true;
        }

        public void Guess(Player player, int value)
        {
            GuessTipp tipp;
            if(value > number) tipp = GuessTipp.ToHeight;
            else if(value < number) tipp = GuessTipp.ToLow;
            else if(value == number) tipp = GuessTipp.Correct;
            else tipp = GuessTipp.Others;
            Guess g = new Guess(value, tipp, player.Name);
            guesses.Add(g);
            foreach (Player p in players)
                p.Client.PlayerGuess(g);
            if(tipp == GuessTipp.Correct)
                foreach(Player p in players)
                    p.Client.GameOver(p==player, guesses);            
        }

        public void RemoveClient(Player player)
        {
            players.Remove(player);            
        }

        public void PlayerLeft(Player player)
        {
            foreach (Player p in players)
                p.Client.PlayerGuess(new Guess(-1, GuessTipp.Others, player.Name));
        }
    }
}
