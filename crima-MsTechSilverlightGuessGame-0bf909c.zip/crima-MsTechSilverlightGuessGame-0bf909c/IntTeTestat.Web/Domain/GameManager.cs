﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntTeTestat.Web.Domain
{
    public class GameManager
    {
        private static GameManager manager;
        private List<Game> games;
        private Dictionary<IGuessService, Player> players;

        public static GameManager Instance
        {
            get
            {
                if (manager == null)
                    manager = new GameManager();
                return manager;
            }
        }

        private GameManager()
        {
            Console.WriteLine("GameManager erstellt");
            games = new List<Game>();
            players = new Dictionary<IGuessService, Player>();
        }

        public void AddClient(IGuessService client)
        {
            players.Add(client, new Player() { Client = client });   
        }

        public void AddName(IGuessService client, string name)
        {
            if (!players.ContainsKey(client)) AddClient(client);
            
                players[client].Name = name;
                foreach (Game g in games)
                {
                    if (!g.Full)
                    {
                        players[client].Game = g;
                        g.Add(players[client]);
                        return;
                    }
                }
                Game game = new Game();
                players[client].Game = game;
                game.Add(players[client]);
                games.Add(game);
            
        }

        public void Guess(IGuessService client, int value)
        {
            if (players.ContainsKey(client))
            {
                if (value == -1)
                    players[client].Game.PlayerLeft(players[client]);
                else
                players[client].Game.Guess(players[client], value);
            }
        }

        public void RemoveClient(IGuessService client)
        {
            if (players.ContainsKey(client))
            {
                players[client].Game.RemoveClient(players[client]);
                if (players[client].Game.Empty)
                    games.Remove(players[client].Game);
                players.Remove(client);                
            }
        }
    }
}