﻿using System;
using IntTeTestat.Web.Domain;
using System.Runtime.Serialization;

namespace IntTeTestat.Web.Util
{
    public enum GuessTipp
    {
        ToLow,
        ToHeight,
        Correct,
        Others
    }


    [Serializable]
    [DataContract]
    public class Guess
    {   
        [DataMember]
        public int GuessNr { get; set; }
        [DataMember]
        public GuessTipp Tipp { get; set; }
        [DataMember]
        public string Player { get; set; }
        public Guess(int guessed, GuessTipp tipp, string playerName )
        {
            GuessNr = guessed;
            Tipp = tipp;
            Player = playerName;
        }
        public Guess() { }
       
    };
}