﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IntTeTestat.Web.Util;

namespace IntTeTestat.Web.Domain
{
    public class Game
    {
       
        public bool Full { get{return players.Count >= maxPlayers;} }
        private List<Player> players = new List<Player>();
        private List<Guess> guesses = new List<Guess>();
        private int maxPlayers = 1;

        private int number = 5; //random

        public void Add(Player player)
        {
            players.Add(player);
            if (Full)
                Start();
        }

        private void Start()
        {
            //var names = from p in players select p.Name;
            //refactor me
            
            List<string> names = new List<string>();
            foreach (Player p in players)
                names.Add(p.Name);
            foreach (Player p in players)
                p.Client.StartGame(names, p.Name);

        }

        public void Guess(Player player, int value)
        {
            GuessTipp tipp;
            if(value > number) tipp = GuessTipp.ToHeight;
            else if(value < number) tipp = GuessTipp.ToLow;
            else if(value == number) tipp = GuessTipp.Correct;
            else tipp = GuessTipp.Others;
            Guess g = new Guess(value, tipp, player.Name);
            guesses.Add(g);
            foreach (Player p in players)
                p.Client.PlayerGuess(g);
        }

        public void RemoveClient(Player player)
        {
            players.Remove(player);            
        }
    }
}
